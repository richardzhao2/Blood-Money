Welcome to PAYDAY 2D, a socket based multiplayer game for 2 players.

To play, run masterclientfinal.py in Python 3.6 or later

The latest version of pygame should be installed to run

In order to set up the multiplayer server, go into game_server.py and change the IP to your own IP address and run that file in a separate terminal.

In order to test out multiplayer capabilities, two different instances of masterclientfinal.py should be run. 